const mongoose = require('mongoose');
// queue and department models
const { Queue, Department } = require('./models/queue');
<<<<<<< HEAD
const { queueData} = require('./data');
const {departments} = require('./data');
=======
const { queueData, departments, beds, inventoryData } = require('./data');
>>>>>>> b459c49cbe4aade307ef0ddedb201a04ccbe450f
// bed model

const { Bed } = require('./models/bed');

<<<<<<< HEAD
const { beds } = require('./data');

=======
const { Inventory } = require('./models/inventory'); 
>>>>>>> b459c49cbe4aade307ef0ddedb201a04ccbe450f
main().catch(err => console.log(err));

async function main() {
  await mongoose.connect('mongodb://127.0.0.1:27017/Medicure');

    console.log("Connected to MongoDB");
}




async function initDatabase() {
    await Queue.deleteMany({});
    await Department.deleteMany({});
    await Bed.deleteMany({});
<<<<<<< HEAD
=======
       await Inventory.deleteMany({});
 
   
>>>>>>> b459c49cbe4aade307ef0ddedb201a04ccbe450f
    
    await Queue.insertMany(queueData);
    await Department.insertMany(departments);
    await Bed.insertMany(beds);
<<<<<<< HEAD
=======
    await Inventory.insertMany(inventoryData);
   
   
>>>>>>> b459c49cbe4aade307ef0ddedb201a04ccbe450f
    
   
    }

initDatabase().then(() => {
    console.log("Initialization complete");
   
}
).catch(err => {
    console.error("Error initializing database:", err);
  
});

<<<<<<< HEAD
=======


>>>>>>> b459c49cbe4aade307ef0ddedb201a04ccbe450f
