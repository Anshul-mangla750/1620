const mongoose = require('mongoose');

const bedSchema = new mongoose.Schema({
  bedId: String,
  ward: String,
  floor: String,
  room: String,
  status: {
    type: String,
    enum: ['available', 'occupied'],
    default: 'available'
  },
  patient: { 
    name: String,
    id: String
  },
  doctor: String,
  condition: String,
  admitDate: Date,
  dischargeDate: Date
});
<<<<<<< HEAD
// const Bed = mongoose.model('Bed', bedSchema);
// module.exports = { Bed };

module.exports = mongoose.models.Bed || mongoose.model("Bed", bedSchema);
=======
const Bed = mongoose.model('Bed', bedSchema);
module.exports = { Bed };

>>>>>>> b459c49cbe4aade307ef0ddedb201a04ccbe450f
